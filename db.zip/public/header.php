<header>
    <div class="left">
        <div class="menu-contenedor">
            <div class="menu" id="menu">
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
        <div class="brand">
            <img src="../Icons/logo-Photoroom-removebg-preview.png" alt="icon-udemy" class="logo">
            <span class="name">DISTRIBUIDORA TEMOZÓN</span>
        </div>
    </div>
    <div class="right">
        <a href="#" class="icons-header">
            <img src="../Icons/warning-svgrepo-com.svg" alt="notificacion">
        </a>
        <a href="#" class="icons-header">
            <img src="../Icons/logout-2-svgrepo-com.svg" alt="salida">
        </a>
        <img src="../Icons/user-svgrepo-com.svg" alt="img-user" class="user">
    </div>
</header>
